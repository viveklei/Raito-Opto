# Raito Opto Electronics Website

A professional, fully-responsive corporate website for Raito Opto Electronics Private Limited - a leading manufacturer of laser cutting solutions.

## 🌟 Features

- **Fully Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Modern Animations** - Smooth transitions and engaging interactions
- **Professional UI/UX** - Clean, corporate design with excellent user experience
- **Multiple Pages** - Complete website with 10+ interconnected pages
- **Login System** - Beautiful animated login page with social authentication
- **Product Catalog** - Filterable products with comparison features
- **Contact Forms** - Interactive contact forms with validation
- **SEO Optimized** - Proper meta tags and semantic HTML

## 📁 File Structure

```
raito-website/
├── index.html              # Homepage
├── styles.css              # Global styles
├── script.js               # Global JavaScript
├── products.html           # Products catalog page
├── products.css            # Products page styles
├── products.js             # Products functionality
├── login.html              # Login/Authentication page
├── login.css               # Login page styles
├── login.js                # Login functionality
├── about.html              # About us page
├── about.css               # About page styles
├── about.js                # About page animations
├── contact.html            # Contact page
├── contact.css             # Contact page styles
├── contact.js              # Contact functionality
├── solutions.html          # Industry solutions page
├── technology.html         # Technology page
├── service.html            # Service & support page
├── company.html            # Company information page
├── common-pages.css        # Shared styles for multiple pages
└── README.md               # This file
```

## 🚀 Quick Start

### Prerequisites
- A code editor (VS Code recommended)
- Live Server extension (for VS Code)
- Modern web browser

### Installation

1. **Create Project Folder**
   ```bash
   mkdir raito-website
   cd raito-website
   ```

2. **Add All Files**
   - Copy all HTML, CSS, and JS files into the folder
   - Ensure file names match exactly as listed above

3. **Open in VS Code**
   ```bash
   code .
   ```

4. **Install Live Server** (if not already installed)
   - Go to Extensions (Ctrl+Shift+X)
   - Search for "Live Server" by Ritwick Dey
   - Click Install

5. **Run the Website**
   - Right-click on `index.html`
   - Select "Open with Live Server"
   - Website will open at `http://localhost:5500`

## 📄 Page Overview

### 🏠 Homepage (index.html)
- Hero slider with 3 slides
- Statistics section
- Features showcase
- Product highlights
- Testimonials
- CTA sections

### 🛒 Products Page (products.html)
- Product filtering by category
- Product comparison feature
- Quick view functionality
- Download brochures
- Animated product cards

### 🔐 Login Page (login.html)
- Animated gradient background
- Floating particles effect
- Email/password authentication
- Social login (Google, Microsoft)
- Password visibility toggle
- Toast notifications

### ℹ️ About Page (about.html)
- Company story
- Mission & vision
- Timeline of milestones
- Team members
- Animated statistics

### 📞 Contact Page (contact.html)
- Multiple contact options
- Interactive contact form
- FAQ section
- Map integration
- Form validation

### 💼 Solutions Page (solutions.html)
- Industry-specific solutions
- Automotive, Aerospace, Medical, etc.
- Use case descriptions
- Feature listings

### 🔬 Technology Page (technology.html)
- Advanced technologies
- Feature comparisons
- Technical specifications
- Innovation highlights

### 🛠️ Service Page (service.html)
- 24/7 support information
- Training programs
- Maintenance services
- Warranty details
- Service statistics

### 🏢 Company Page (company.html)
- Company information
- Global presence
- Certifications
- Career opportunities
- Latest news

## 🎨 Design Features

### Color Scheme
- **Primary Red:** #d32f2f
- **Dark Red:** #b71c1c
- **Light Gray:** #f8f8f8
- **Dark Gray:** #1a1a1a

### Typography
- Font Family: 'Segoe UI', Arial, 'Helvetica Neue', sans-serif
- Responsive font sizes
- Clear hierarchy

### Animations
- Smooth page transitions
- Hover effects on all interactive elements
- Scroll-triggered animations
- Loading animations
- Counter animations
- Particle effects (login page)

## 🔧 Customization

### Changing Colors
Edit the CSS variables in `styles.css`:
```css
:root {
    --primary-red: #d32f2f;
    --dark-red: #b71c1c;
    --light-gray: #f8f8f8;
    --dark-gray: #1a1a1a;
}
```

### Adding Products
Edit the products grid in `products.html`:
```html
<div class="product-item" data-category="fiber">
    <!-- Product content -->
</div>
```

### Modifying Contact Information
Update the top header in each HTML file:
```html
<span>📧 your@email.com</span>
<span>📞 +91 (xxx) xxx-xxxx</span>
```

## 📱 Responsive Breakpoints

- **Desktop:** > 1024px
- **Tablet:** 768px - 1024px
- **Mobile:** < 768px

## ✨ Key Features by Page

### Products Page
- ✅ Category filtering
- ✅ Product comparison (up to 4 items)
- ✅ Quick view modals
- ✅ Brochure downloads
- ✅ Sticky filter bar

### Login Page
- ✅ Animated background with gradient orbs
- ✅ Floating particles
- ✅ Form validation
- ✅ Password toggle
- ✅ Remember me function
- ✅ Social login buttons
- ✅ Toast notifications

### Contact Page
- ✅ Multi-step contact options
- ✅ Form validation
- ✅ FAQ accordion
- ✅ Map placeholder
- ✅ Social media links

## 🔒 Login Functionality

The login page includes:
- Email/password authentication (demo mode)
- Form validation
- Loading states
- Success/error notifications
- Remember me option
- Social authentication UI (Google, Microsoft)

**Note:** This is a frontend demo. For production use, implement backend authentication.

## 📊 Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Opera (latest)

## 🎯 Performance

- Optimized CSS with minimal redundancy
- Efficient JavaScript with event delegation
- Lazy loading for images (ready for implementation)
- Smooth 60fps animations
- Minimal external dependencies

## 📝 Future Enhancements

- [ ] Backend API integration
- [ ] Real authentication system
- [ ] Database for products
- [ ] Shopping cart functionality
- [ ] User dashboard
- [ ] Blog section
- [ ] Multi-language support
- [ ] Dark mode toggle

## 🐛 Troubleshooting

### Page not loading?
- Check that all files are in the same folder
- Verify file names match exactly (case-sensitive)
- Ensure Live Server is running

### Styles not applying?
- Check CSS file links in HTML
- Clear browser cache (Ctrl+F5)
- Verify CSS file names

### JavaScript not working?
- Check browser console for errors (F12)
- Verify script.js is linked at bottom of body
- Ensure file paths are correct

## 📞 Support

For questions or issues:
- Email: sales@raitoopto.com
- Phone: +91 (422) 123-4567

## 📄 License

© 2024 Raito Opto Electronics Private Limited. All rights reserved.

## 🙏 Credits

Designed and developed for Raito Opto Electronics Private Limited
- Professional corporate design
- Modern UI/UX practices
- Responsive layouts
- Accessible components

---

**Version:** 1.0.0  
**Last Updated:** November 2024  
**Status:** Production Ready ✅#   R a i t o - O p t o  
 